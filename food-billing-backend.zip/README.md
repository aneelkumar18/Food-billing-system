# Food Billing System - Backend (Node + Express + SQLite)

## Run locally

1. cd backend
2. npm install
3. npm run seed   # creates SQLite DB and seeds sample menu items
4. npm run dev    # requires nodemon (or use npm start)

API base: http://localhost:4000/api

Endpoints:
- GET  /api/menu
- POST /api/menu
- PUT  /api/menu/:id
- POST /api/orders
- GET  /api/orders
- GET  /api/orders/:id
- GET  /api/invoices/:orderId
