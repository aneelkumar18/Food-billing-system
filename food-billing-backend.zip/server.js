const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const db = require('./db');
const fs = require('fs');
const path = require('path');

// ensure DB tables exist by running init.sql
const initSql = fs.readFileSync(path.join(__dirname, 'models', 'init.sql'), 'utf8');
initSql.split(';').forEach(stmt => { if (stmt.trim()) db.prepare(stmt).run(); });

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api/menu', require('./routes/menu'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/invoices', require('./routes/invoices'));

app.get('/', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Backend running on', PORT));
