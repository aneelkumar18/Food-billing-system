const db = require('./db');
const fs = require('fs');
const path = require('path');

// initialize schema
const initSql = fs.readFileSync(path.join(__dirname, 'models', 'init.sql'), 'utf8');
initSql.split(';').forEach(stmt => {
  if (stmt.trim()) db.prepare(stmt).run();
});

// seed menu items
const items = [
  { name: 'Margherita Pizza', sku: 'PZ001', category: 'Pizza', price: 199, tax_percent: 5 },
  { name: 'Veg Burger', sku: 'BG001', category: 'Burgers', price: 129, tax_percent: 5 },
  { name: 'French Fries', sku: 'FR001', category: 'Sides', price: 79, tax_percent: 5 },
  { name: 'Cold Coffee', sku: 'CF001', category: 'Drinks', price: 89, tax_percent: 5 }
];

const insert = db.prepare('INSERT OR IGNORE INTO menu_items (name, sku, category, price, tax_percent) VALUES (@name, @sku, @category, @price, @tax_percent)');
const insertMany = db.transaction((arr) => {
  for (const it of arr) insert.run(it);
});
insertMany(items);

console.log('Seeded DB with menu items.');
