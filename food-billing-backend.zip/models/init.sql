-- menu_items
CREATE TABLE IF NOT EXISTS menu_items (
  item_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sku TEXT UNIQUE,
  category TEXT,
  price REAL NOT NULL,
  tax_percent REAL DEFAULT 0,
  is_available INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now'))
);

-- orders
CREATE TABLE IF NOT EXISTS orders (
  order_id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_type TEXT,
  table_no TEXT,
  customer_name TEXT,
  status TEXT DEFAULT 'open',
  subtotal REAL,
  tax_total REAL,
  discount_total REAL,
  round_off REAL,
  total REAL,
  created_at TEXT DEFAULT (datetime('now'))
);

-- order_items
CREATE TABLE IF NOT EXISTS order_items (
  order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER,
  item_id INTEGER,
  quantity INTEGER,
  price_at_sale REAL,
  discount REAL DEFAULT 0,
  FOREIGN KEY(order_id) REFERENCES orders(order_id),
  FOREIGN KEY(item_id) REFERENCES menu_items(item_id)
);

-- invoices
CREATE TABLE IF NOT EXISTS invoices (
  invoice_id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER,
  invoice_total REAL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(order_id) REFERENCES orders(order_id)
);
