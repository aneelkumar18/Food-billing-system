const express = require('express');
const router = express.Router();
const db = require('../db');
const { v4: uuidv4 } = require('uuid');

// create order
router.post('/', (req, res) => {
  try {
    const { order_type, table_no, customer_name, items, discount = 0 } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Items required' });

    // calculate amounts
    let subtotal = 0;
    let tax_total = 0;

    const getItem = db.prepare('SELECT * FROM menu_items WHERE item_id = ?');

    for (const it of items) {
      const dbItem = getItem.get(it.item_id);
      if (!dbItem) return res.status(400).json({ error: 'Invalid item id ' + it.item_id });
      const line = dbItem.price * it.quantity;
      subtotal += line;
      tax_total += line * (dbItem.tax_percent / 100);
    }

    const total_before_round = subtotal + tax_total - discount;
    const round_off = Math.round(total_before_round) - total_before_round; // to nearest integer
    const total = + (total_before_round + round_off).toFixed(2);

    const insertOrder = db.prepare('INSERT INTO orders (order_type, table_no, customer_name, subtotal, tax_total, discount_total, round_off, total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    const info = insertOrder.run(order_type, table_no, customer_name, subtotal, tax_total, discount, round_off, total, 'closed');
    const orderId = info.lastInsertRowid;

    const insertItem = db.prepare('INSERT INTO order_items (order_id, item_id, quantity, price_at_sale, discount) VALUES (?, ?, ?, ?, ?)');
    const insertMany = db.transaction((rows) => {
      for (const it of rows) insertItem.run(it.order_id, it.item_id, it.quantity, it.price_at_sale, it.discount || 0);
    });

    const orderRows = items.map(it => ({ order_id: orderId, item_id: it.item_id, quantity: it.quantity, price_at_sale: getItem.get(it.item_id).price, discount: it.discount || 0 }));
    insertMany(orderRows);

    res.json({ order_id: orderId, subtotal, tax_total, discount, round_off, total });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// list orders
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  res.json(rows);
});

// order details
router.get('/:id', (req, res) => {
  const id = req.params.id;
  const order = db.prepare('SELECT * FROM orders WHERE order_id = ?').get(id);
  if(!order) return res.status(404).json({ error: 'Order not found' });
  const items = db.prepare('SELECT oi.*, mi.name FROM order_items oi JOIN menu_items mi ON oi.item_id = mi.item_id WHERE oi.order_id = ?').all(id);
  res.json({ order, items });
});

module.exports = router;
