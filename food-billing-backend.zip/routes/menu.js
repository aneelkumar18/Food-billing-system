const express = require('express');
const router = express.Router();
const db = require('../db');

// get menu
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM menu_items WHERE is_available = 1').all();
  res.json(rows);
});

// create menu item
router.post('/', (req, res) => {
  const { name, sku, category, price, tax_percent } = req.body;
  const stmt = db.prepare('INSERT INTO menu_items (name, sku, category, price, tax_percent) VALUES (?, ?, ?, ?, ?)');
  const info = stmt.run(name, sku, category, price, tax_percent || 0);
  res.json({ item_id: info.lastInsertRowid });
});

// update
router.put('/:id', (req, res) => {
  const id = req.params.id;
  const { name, sku, category, price, tax_percent, is_available } = req.body;
  const stmt = db.prepare('UPDATE menu_items SET name = ?, sku = ?, category = ?, price = ?, tax_percent = ?, is_available = ? WHERE item_id = ?');
  stmt.run(name, sku, category, price, tax_percent || 0, is_available ? 1 : 0, id);
  res.json({ ok: true });
});

module.exports = router;
