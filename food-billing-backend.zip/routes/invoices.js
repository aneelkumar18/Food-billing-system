const express = require('express');
const router = express.Router();
const db = require('../db');
const jsPDF = require('jspdf');

// generate invoice as JSON (frontend can render PDF)
router.get('/:orderId', (req, res) => {
  const orderId = req.params.orderId;
  const order = db.prepare('SELECT * FROM orders WHERE order_id = ?').get(orderId);
  const items = db.prepare('SELECT oi.*, mi.name FROM order_items oi JOIN menu_items mi ON oi.item_id = mi.item_id WHERE oi.order_id = ?').all(orderId);
  if (!order) return res.status(404).json({ error: 'Not found' });
  res.json({ order, items });
});

module.exports = router;
