import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import API from '../api';
import jsPDF from 'jspdf';

export default function InvoiceView(){
  const { id } = useParams();
  const [data, setData] = useState(null);

  useEffect(()=>{
    API.get(`/invoices/${id}`).then(r=>setData(r.data));
  },[id]);

  const downloadPDF = ()=>{
    if(!data) return;
    const doc = new jsPDF();
    doc.text(`Invoice #${id}`, 10, 10);
    doc.text(`Total: ₹${data.order.total}`, 10, 20);
    let y = 30;
    data.items.forEach(it=>{ doc.text(`${it.name} x${it.quantity} — ₹${(it.price_at_sale*it.quantity).toFixed(2)}`, 10, y); y+=8; });
    doc.save(`invoice-${id}.pdf`);
  }

  if(!data) return <div>Loading...</div>;
  return (
    <div>
      <h1>Invoice #{id}</h1>
      <div>Total: ₹{data.order.total}</div>
      <ul>{data.items.map(it => <li key={it.order_item_id}>{it.name} x{it.quantity} — ₹{(it.price_at_sale*it.quantity).toFixed(2)}</li>)}</ul>
      <button onClick={downloadPDF}>Download PDF</button>
    </div>
  )
}
