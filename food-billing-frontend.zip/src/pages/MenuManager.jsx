import React, { useEffect, useState } from 'react';
import API from '../api';

export default function MenuManager(){
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name:'', sku:'', category:'', price:0, tax_percent:5 });

  useEffect(()=>{ API.get('/menu').then(r=>setItems(r.data)); },[]);

  const add = async (e)=>{
    e.preventDefault();
    await API.post('/menu', form);
    const r = await API.get('/menu'); setItems(r.data);
  }

  return (
    <div>
      <h1>Menu Manager</h1>
      <form onSubmit={add} className="card">
        <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
        <input placeholder="SKU" value={form.sku} onChange={e=>setForm({...form, sku:e.target.value})} />
        <input placeholder="Category" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} />
        <input type="number" placeholder="Price" value={form.price} onChange={e=>setForm({...form, price:+e.target.value})} required />
        <input type="number" placeholder="Tax %" value={form.tax_percent} onChange={e=>setForm({...form, tax_percent:+e.target.value})} />
        <button type="submit">Add</button>
      </form>

      <h2>Items</h2>
      <ul>
        {items.map(it=> <li key={it.item_id}>{it.name} — ₹{it.price}</li>)}
      </ul>
    </div>
  )
}
