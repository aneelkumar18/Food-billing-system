import React, { useEffect, useState } from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';

export default function POS(){
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState([]);
  const [discount, setDiscount] = useState(0);
  const nav = useNavigate();

  useEffect(()=>{ API.get('/menu').then(r=>setMenu(r.data)); },[]);

  const addToCart = (item) => {
    const found = cart.find(c=>c.item_id===item.item_id);
    if(found) setCart(cart.map(c=> c.item_id===item.item_id ? {...c, quantity: c.quantity+1} : c));
    else setCart([...cart, {...item, quantity:1}]);
  }

  const placeOrder = async ()=>{
    const payload = { order_type: 'takeaway', items: cart.map(c=>({ item_id: c.item_id, quantity: c.quantity })), discount };
    const r = await API.post('/orders', payload);
    nav(`/invoice/${r.data.order_id}`);
  }

  const subtotal = cart.reduce((s,c)=> s + c.price * c.quantity, 0);
  const tax = cart.reduce((s,c)=> s + c.price * c.quantity * (c.tax_percent/100), 0);
  const totalBefore = subtotal + tax - discount;
  const roundOff = Math.round(totalBefore) - totalBefore;
  const total = +(totalBefore + roundOff).toFixed(2);

  return (
    <div>
      <h1>POS</h1>
      <div className="grid">
        <div>
          <h2>Menu</h2>
          <ul>
            {menu.map(m=> (
              <li key={m.item_id}>
                {m.name} — ₹{m.price}
                <button onClick={()=>addToCart(m)}>Add</button>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2>Cart</h2>
          <ul>
            {cart.map(c=> <li key={c.item_id}>{c.name} x {c.quantity}</li>)}
          </ul>
          <div>Subtotal: ₹{subtotal.toFixed(2)}</div>
          <div>Tax: ₹{tax.toFixed(2)}</div>
          <div>
            <label>Discount: ₹<input type="number" value={discount} onChange={e=>setDiscount(+e.target.value)} /></label>
          </div>
          <div>Round off: ₹{roundOff.toFixed(2)}</div>
          <div>Total: ₹{total}</div>
          <button onClick={placeOrder} disabled={cart.length===0}>Place Order</button>
        </div>
      </div>
    </div>
  )
}
