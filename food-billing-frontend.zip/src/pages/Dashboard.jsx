import React, { useEffect, useState } from 'react';
import API from '../api';

export default function Dashboard(){
  const [orders, setOrders] = useState([]);
  useEffect(()=>{ API.get('/orders').then(r=>setOrders(r.data)); },[]);
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Recent orders:</p>
      <ul>
        {orders.map(o=> <li key={o.order_id}>#{o.order_id} — ₹{o.total} — {o.created_at}</li>)}
      </ul>
    </div>
  )
}
