import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import MenuManager from './pages/MenuManager';
import POS from './pages/POS';
import InvoiceView from './pages/InvoiceView';

export default function App(){
  return (
    <div className="app">
      <nav className="nav">
        <Link to="/">Dashboard</Link>
        <Link to="/menu">Menu</Link>
        <Link to="/pos">POS</Link>
      </nav>
      <main className="main">
        <Routes>
          <Route path="/" element={<Dashboard/>} />
          <Route path="/menu" element={<MenuManager/>} />
          <Route path="/pos" element={<POS/>} />
          <Route path="/invoice/:id" element={<InvoiceView/>} />
        </Routes>
      </main>
    </div>
  );
}
